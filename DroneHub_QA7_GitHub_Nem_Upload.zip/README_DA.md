# DroneHub QA7 – GitHub Pages udviklingsversion

Status: Repository oprettet, men QA7 er endnu ikke uploadet. Appen er IKKE klar til lancering.

## Den nemme vej: 2 trin

1. I Google Chrome: https://github.com/cliffdkp1990/dronehub-preview/upload/main
   Upload `index.html` og `chrome-test.html` fra denne mappe. Tryk på Commit changes / Propose changes og vælg `main`.
   **Upload ikke ZIP-filen direkte**; GitHub udpakker den ikke automatisk.
   Hvis Upload-siden ikke virker, åbn https://github.com/cliffdkp1990/dronehub-preview og vælg `uploading an existing file` eller Add file > Upload files.

2. Åbn https://github.com/cliffdkp1990/dronehub-preview/settings/pages
   Under Build and deployment: `Deploy from a branch` / `main` / `/(root)` / `Save`.

Afvent publicering, kontrollér derefter i Chrome:
https://cliffdkp1990.github.io/dronehub-preview/

Hvis der står 404 efter nogle minutter, se fanen Actions og kontrollér Pages-indstillingerne. GitHub skriver, at første publicering kan tage op til 10-20 minutter.

GitHub skriverettigheder fra ChatGPT er endnu ikke aktiveret; automatisk upload returnerede `403 Resource not accessible by integration`. Til fremtidige automatiske opdateringer skal GitHub-pluginforbindelsen have `Contents: Read and write` og adgang til dette repository. Anvend Settings > Plugins > GitHub og kontrollér forbindelsen/repositoryadgangen, eller administrer GitHub-appens installation på GitHub.

Lovable-preview (ældste version): https://id-preview--0946e7fc-d258-4067-915f-ea26979922c7.lovable.app

Denne pakke indeholder fungerende QA7-kode, men ikke verificerede checkoutpriser og ikke udført fysisk Chrome-test på iPhone.
